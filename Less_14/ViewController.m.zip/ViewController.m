//
//  ViewController.m
//  Less_14
//
//  Created by Nikita Vintonovich on 9/26/17.
//  Copyright © 2017 Vint-Rock. All rights reserved.
//

#import "ViewController.h"

typedef void (^CompletionBlock)(BOOL success, NSError *error);


@interface ViewController ()

@property (nonatomic, copy) void (^SomeBlock)(void);
@property (nonatomic, copy) NSInteger (^SomeBlock_2)(void);
@property (nonatomic, copy) NSInteger (^SomeBlock_3)(NSString *name, NSInteger age);

@property (nonatomic, copy) NSString*(^BlockWithBlock)(NSString* name, void(^block)(NSString* string));

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.BlockWithBlock = ^NSString *(NSString *name, void (^block)(NSString *string)) {
        if (block)
        {
            block(name);
        }
        
        return [NSString stringWithFormat:@"String: %@", name];
    };
    
    self.BlockWithBlock(@"Peter", nil);
                        
    self.SomeBlock_3 = ^NSInteger(NSString *name, NSInteger age) {
        return name.length;
    };
    
    if (self.SomeBlock_3)
    {
        self.SomeBlock_3(@"Name", 32);
    }
    
    __block NSInteger value = 5;
    
    void (^TestBlock)(void) = ^{
        NSLog(@"Test Block Code Here... %lu", value);
        value = 4;
    };
    
    NSLog(@"Test Block Code Here... %lu", value);
    TestBlock();
    NSLog(@"Test Block Code Here... %lu", value);
    
    NSInteger (^blockName)(void) = ^NSInteger()
    {
        return 24;
    };
    
    NSInteger someIntValue = blockName();
    NSLog(@"Some Value = %lu", someIntValue);
    
    [self runWithCompletionBlock:TestBlock];
    
    [self runWithCompletionBlock:nil];
    [self runWithCompletionBlock:^{
        NSLog(@"Run block with method...");
    }];
    
    [self runWithBlockWithParameters:^(NSString *name, NSUInteger age) {
        NSLog(@"Name: %@, Age: %lu", name, age);
    }];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self displayAlertController];
}

- (void)runWithBlockWithParameters:(void(^)(NSString *name, NSUInteger age))completionBlock
{
    if (completionBlock)
    {
        completionBlock(@"John", 23);
    }
}

- (void)runWithCompletionBlock:(void(^)(void))completionBlock
{
    if (completionBlock)
    {
        completionBlock();
    }
}

- (void)displayAlertController
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Alert"
                                                                   message:@"Do you want to become iOS Developer?"
                                                            preferredStyle:UIAlertControllerStyleAlert]; // 1 UIAlertControllerStyleActionSheet
    UIAlertAction *firstAction = [UIAlertAction actionWithTitle:@"NO"
                                                          style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
                                                              NSLog(@"You pressed button NO");
                                                          }]; // 2
    UIAlertAction *secondAction = [UIAlertAction actionWithTitle:@"YES"
                                                           style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
                                                               NSLog(@"You pressed button YES");
                                                           }]; // 3
    
    [alert addAction:firstAction]; // 4
    [alert addAction:secondAction]; // 5
    
    [self presentViewController:alert animated:YES completion:nil]; // 6
}

@end
